-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 10, 2022 at 07:57 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `farmshop`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `admin_id` int(11) NOT NULL,
  `firstname` varchar(20) NOT NULL,
  `lastname` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`admin_id`, `firstname`, `lastname`, `email`, `password`) VALUES
(1, 'masaba', 'shamsa', 'shamsa@gmail.com', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `category_id` int(11) NOT NULL,
  `name` text NOT NULL,
  `longterm` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`category_id`, `name`, `longterm`) VALUES
(1, 'meat ', 70),
(2, 'animal feed', 1000),
(3, 'dairy products', 10000),
(4, 'biogas and manure', 10000);

-- --------------------------------------------------------

--
-- Table structure for table `dailysales`
--

CREATE TABLE `dailysales` (
  `ID` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp(),
  `totalSales` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `dailysales`
--

INSERT INTO `dailysales` (`ID`, `category_id`, `date`, `totalSales`) VALUES
(9, 1, '2022-08-10', 5),
(10, 2, '2022-08-10', 0),
(11, 3, '2022-08-10', 4),
(12, 4, '2022-08-10', 7),
(13, 1, '2022-08-10', 5),
(14, 2, '2022-08-10', 0),
(15, 3, '2022-08-10', 4),
(16, 4, '2022-08-10', 0),
(17, 1, '2022-08-10', 5),
(18, 2, '2022-08-10', 0),
(19, 3, '2022-08-10', 4),
(20, 4, '2022-08-10', 0);

-- --------------------------------------------------------

--
-- Table structure for table `likedproducts`
--

CREATE TABLE `likedproducts` (
  `ID` int(15) NOT NULL,
  `product_id` int(11) NOT NULL,
  `userId` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `likedproducts`
--

INSERT INTO `likedproducts` (`ID`, `product_id`, `userId`) VALUES
(1, 4, 2),
(6, 5, 2),
(7, 5, 0),
(8, 4, 0);

-- --------------------------------------------------------

--
-- Table structure for table `ordered_products`
--

CREATE TABLE `ordered_products` (
  `id` int(11) NOT NULL,
  `product_id` int(15) NOT NULL,
  `quantity` int(20) NOT NULL,
  `subtotal` int(20) NOT NULL,
  `order_id` int(15) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ordered_products`
--

INSERT INTO `ordered_products` (`id`, `product_id`, `quantity`, `subtotal`, `order_id`, `date`) VALUES
(3, 4, 21, 21000, 3, '2022-08-09'),
(4, 6, 10, 6000, 3, '2022-08-09'),
(5, 7, 1, 50000, 4, '2022-08-09'),
(6, 4, 1, 1000, 5, '2022-08-10'),
(7, 5, 3, 21000, 5, '2022-08-10'),
(8, 6, 4, 2400, 6, '2022-08-10'),
(9, 4, 10, 10000, 6, '2022-08-10'),
(10, 4, 13, 13000, 6, '2022-08-10'),
(11, 4, 2, 2000, 7, '2022-08-10'),
(12, 7, 11, 550000, 7, '2022-08-10'),
(13, 4, 9, 9000, 8, '2022-08-10'),
(14, 5, 10, 70000, 8, '2022-08-10'),
(15, 7, 10, 500000, 9, '2022-08-10'),
(16, 6, 8, 4800, 9, '2022-08-10'),
(17, 7, 23, 1150000, 10, '2022-08-10'),
(18, 6, 9, 5400, 10, '2022-08-10'),
(19, 5, 23, 161000, 11, '2022-08-10'),
(20, 7, 4, 200000, 11, '2022-08-10'),
(21, 7, 23, 1150000, 12, '2022-08-10'),
(22, 5, 5, 35000, 12, '2022-08-10'),
(23, 4, 2, 2000, 13, '2022-08-10'),
(24, 5, 6, 42000, 13, '2022-08-10'),
(25, 4, 9, 9000, 14, '2022-08-10'),
(26, 5, 8, 56000, 14, '2022-08-10'),
(27, 4, 2, 2000, 15, '2022-08-10'),
(28, 5, 3, 21000, 15, '2022-08-10');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `customer_id` int(15) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp(),
  `cart_total` int(20) NOT NULL,
  `status` varchar(10) NOT NULL DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `customer_id`, `date`, `cart_total`, `status`) VALUES
(3, 4, '2022-08-09', 27000, 'pending'),
(4, 2, '2022-08-09', 50000, 'pending'),
(5, 4, '2022-08-10', 22000, 'pending'),
(6, 4, '2022-08-10', 25400, 'pending'),
(7, 4, '2022-08-10', 552000, 'pending'),
(8, 4, '2022-08-10', 79000, 'pending'),
(9, 4, '2022-08-10', 504800, 'pending'),
(10, 4, '2022-08-10', 1155400, 'pending'),
(11, 4, '2022-08-10', 361000, 'pending'),
(12, 4, '2022-08-10', 1185000, 'pending'),
(13, 4, '2022-08-10', 44000, 'pending'),
(14, 4, '2022-08-10', 65000, 'pending'),
(15, 2, '2022-08-10', 23000, 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `name` varchar(15) NOT NULL,
  `price` varchar(10) NOT NULL,
  `likes` int(11) NOT NULL DEFAULT 0,
  `category_id` int(11) NOT NULL,
  `imageurl` varchar(255) NOT NULL DEFAULT 'not available'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `name`, `price`, `likes`, `category_id`, `imageurl`) VALUES
(4, 'milk', '1000', 12, 3, 'img/milk3.jpg'),
(5, 'beef', '7000', 10, 1, 'img/meat3.jpg'),
(6, 'pig feed', '600', 4, 2, 'img/feed2.jpg'),
(7, 'biogas', '50000', 24, 4, 'img/biogas1.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `staff_id` int(11) NOT NULL,
  `firstname` varchar(11) NOT NULL,
  `lastname` varchar(15) NOT NULL,
  `tel` int(11) NOT NULL,
  `category_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`staff_id`, `firstname`, `lastname`, `tel`, `category_id`) VALUES
(3, 'Achuka', 'Simon', 775609882, 1),
(4, 'Duku', 'Juma', 783254534, 1),
(5, 'Namuya', 'John', 790474533, 1),
(6, 'Namirembe', 'Vicky', 743434363, 1),
(7, 'Apio', 'Janet', 784643634, 1),
(8, 'Kigwana', 'Authur', 794635373, 2),
(9, 'Jamila', 'Kabatuku', 748474644, 1),
(10, 'Kisakye', 'Esther', 784475463, 1),
(11, 'Ayo', 'Mary', 794645844, 1),
(12, 'Ayiko', 'Mark', 94746484, 3),
(13, 'Wedi', 'Faruk', 847484746, 4),
(14, 'Wasenyi', 'Simon', 273637338, 4),
(15, 'Waholi', 'Peter', 2735383, 4);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `firstname` varchar(15) NOT NULL,
  `lastname` varchar(15) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` text NOT NULL,
  `address` varchar(15) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `CM` int(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `firstname`, `lastname`, `email`, `password`, `address`, `gender`, `CM`) VALUES
(1, 'asiimwe', 'christine', 'chr@gmail.com', '1234', 'kiwatule', 'F', 0),
(2, 'masaba', 'shamsa', 'shamsa@gmail.com', '1234', 'namungoona', 'F', 0),
(3, 'nveghfvwe', 'nvd', 'dhbfhwe@gms.con', 'gdyd', 'M', '32', 0),
(4, 'kiiza', 'christian', 'xankiiza@gmail.com', '1234', 'ntinda', 'M', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `dailysales`
--
ALTER TABLE `dailysales`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `likedproducts`
--
ALTER TABLE `likedproducts`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `ordered_products`
--
ALTER TABLE `ordered_products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`staff_id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `dailysales`
--
ALTER TABLE `dailysales`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `likedproducts`
--
ALTER TABLE `likedproducts`
  MODIFY `ID` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `ordered_products`
--
ALTER TABLE `ordered_products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `staff_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`);

--
-- Constraints for table `staff`
--
ALTER TABLE `staff`
  ADD CONSTRAINT `staff_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
